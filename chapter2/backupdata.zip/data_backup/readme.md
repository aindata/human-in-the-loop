Once the annotation is done code modifies the data files, but this folder contains the untouched version of these files
---
Following files are backed up with the same name in this folder:
- unlabeled_data/unlabebled_data.csv
- evaluation_data/related.csv
- evaluation_data/not_related.csv
- validation_data/related.csv
- validation_data/not_related.csv
- training_data/related.csv
- training_data/not_related.csv